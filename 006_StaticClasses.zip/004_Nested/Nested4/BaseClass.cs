﻿using System;

namespace Nested
{
    public class BaseClass
    {
        public void MethodFromBase()
        {
            Console.WriteLine("Метод Базового класу.");
        }
    }
}
