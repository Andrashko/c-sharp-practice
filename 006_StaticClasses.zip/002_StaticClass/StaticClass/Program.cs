﻿using System;

// Статичні класи.

namespace Static
{
    class Program
    {
        static void Main()
        {
            StaticClass.StaticMethod();

            // Delay.
            Console.ReadKey();
        }
    }
}
