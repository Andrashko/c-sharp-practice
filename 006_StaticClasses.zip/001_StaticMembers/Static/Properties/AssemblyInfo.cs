﻿using System.Reflection;

[assembly: AssemblyProduct("C# Essential")]
[assembly: AssemblyCompany("CyberBionic Systematics")]
[assembly: AssemblyCopyright("Copyright © CyberBionic Systematics 2015")]
